/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AppSignonPolicyConfig extends cdktf.TerraformMetaArguments {
    /**
    * If false, the default rule of the policy is set access to `DENY`. Otherwise default behavior of the default rule is to leave access at `ALLOW`.  **WARNING** setting this attribute to false changes policy rule's default behavior. Use at your own risk. This is only applied during creation and does not affect import or update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/app_signon_policy#catch_all AppSignonPolicy#catch_all}
    */
    readonly catchAll?: boolean | cdktf.IResolvable;
    /**
    * Description of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/app_signon_policy#description AppSignonPolicy#description}
    */
    readonly description: string;
    /**
    * Name of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/app_signon_policy#name AppSignonPolicy#name}
    */
    readonly name: string;
    /**
    * Priority of the policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/app_signon_policy#priority AppSignonPolicy#priority}
    */
    readonly priority?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/app_signon_policy okta_app_signon_policy}
*/
export declare class AppSignonPolicy extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_app_signon_policy";
    /**
    * Generates CDKTF code for importing a AppSignonPolicy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppSignonPolicy to import
    * @param importFromId The id of the existing AppSignonPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/app_signon_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppSignonPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/app_signon_policy okta_app_signon_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppSignonPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AppSignonPolicyConfig);
    private _catchAll?;
    get catchAll(): boolean | cdktf.IResolvable;
    set catchAll(value: boolean | cdktf.IResolvable);
    resetCatchAll(): void;
    get catchAllInput(): boolean | cdktf.IResolvable | undefined;
    get defaultRuleId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
