/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaDefaultSigninPageConfig extends cdktf.TerraformMetaArguments {
    /**
    * brand id of the preview signin page
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/default_signin_page#brand_id DataOktaDefaultSigninPage#brand_id}
    */
    readonly brandId: string;
}
export interface DataOktaDefaultSigninPageContentSecurityPolicySetting {
}
export declare function dataOktaDefaultSigninPageContentSecurityPolicySettingToTerraform(struct?: DataOktaDefaultSigninPageContentSecurityPolicySetting | cdktf.IResolvable): any;
export declare function dataOktaDefaultSigninPageContentSecurityPolicySettingToHclTerraform(struct?: DataOktaDefaultSigninPageContentSecurityPolicySetting | cdktf.IResolvable): any;
export declare class DataOktaDefaultSigninPageContentSecurityPolicySettingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDefaultSigninPageContentSecurityPolicySetting | cdktf.IResolvable | undefined;
    set internalValue(value: DataOktaDefaultSigninPageContentSecurityPolicySetting | cdktf.IResolvable | undefined);
    get mode(): string;
    get reportUri(): string;
    get srcList(): string[];
}
export interface DataOktaDefaultSigninPageWidgetCustomizations {
}
export declare function dataOktaDefaultSigninPageWidgetCustomizationsToTerraform(struct?: DataOktaDefaultSigninPageWidgetCustomizations | cdktf.IResolvable): any;
export declare function dataOktaDefaultSigninPageWidgetCustomizationsToHclTerraform(struct?: DataOktaDefaultSigninPageWidgetCustomizations | cdktf.IResolvable): any;
export declare class DataOktaDefaultSigninPageWidgetCustomizationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDefaultSigninPageWidgetCustomizations | cdktf.IResolvable | undefined;
    set internalValue(value: DataOktaDefaultSigninPageWidgetCustomizations | cdktf.IResolvable | undefined);
    get authenticatorPageCustomLinkLabel(): string;
    get authenticatorPageCustomLinkUrl(): string;
    get classicRecoveryFlowEmailOrUsernameLabel(): string;
    get customLink1Label(): string;
    get customLink1Url(): string;
    get customLink2Label(): string;
    get customLink2Url(): string;
    get forgotPasswordLabel(): string;
    get forgotPasswordUrl(): string;
    get helpLabel(): string;
    get helpUrl(): string;
    get passwordInfoTip(): string;
    get passwordLabel(): string;
    get showPasswordVisibilityToggle(): cdktf.IResolvable;
    get showUserIdentifier(): cdktf.IResolvable;
    get signInLabel(): string;
    get unlockAccountLabel(): string;
    get unlockAccountUrl(): string;
    get usernameInfoTip(): string;
    get usernameLabel(): string;
    get widgetGeneration(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/default_signin_page okta_default_signin_page}
*/
export declare class DataOktaDefaultSigninPage extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_default_signin_page";
    /**
    * Generates CDKTF code for importing a DataOktaDefaultSigninPage resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaDefaultSigninPage to import
    * @param importFromId The id of the existing DataOktaDefaultSigninPage that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/default_signin_page#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaDefaultSigninPage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/default_signin_page okta_default_signin_page} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaDefaultSigninPageConfig
    */
    constructor(scope: Construct, id: string, config: DataOktaDefaultSigninPageConfig);
    private _brandId?;
    get brandId(): string;
    set brandId(value: string);
    get brandIdInput(): string | undefined;
    get id(): string;
    get pageContent(): string;
    get widgetVersion(): string;
    private _contentSecurityPolicySetting;
    get contentSecurityPolicySetting(): DataOktaDefaultSigninPageContentSecurityPolicySettingOutputReference;
    private _widgetCustomizations;
    get widgetCustomizations(): DataOktaDefaultSigninPageWidgetCustomizationsOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
