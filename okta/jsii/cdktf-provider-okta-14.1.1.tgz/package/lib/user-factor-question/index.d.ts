/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface UserFactorQuestionConfig extends cdktf.TerraformMetaArguments {
    /**
    * Security question answer. Note here that answer won't be set during the resource import.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/user_factor_question#answer UserFactorQuestion#answer}
    */
    readonly answer: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/user_factor_question#id UserFactorQuestion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Security question unique key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/user_factor_question#key UserFactorQuestion#key}
    */
    readonly key: string;
    /**
    * ID of the user. Resource will be recreated when `user_id` changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/user_factor_question#user_id UserFactorQuestion#user_id}
    */
    readonly userId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/user_factor_question okta_user_factor_question}
*/
export declare class UserFactorQuestion extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_user_factor_question";
    /**
    * Generates CDKTF code for importing a UserFactorQuestion resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserFactorQuestion to import
    * @param importFromId The id of the existing UserFactorQuestion that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/user_factor_question#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserFactorQuestion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/user_factor_question okta_user_factor_question} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserFactorQuestionConfig
    */
    constructor(scope: Construct, id: string, config: UserFactorQuestionConfig);
    private _answer?;
    get answer(): string;
    set answer(value: string);
    get answerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    get status(): string;
    get text(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
