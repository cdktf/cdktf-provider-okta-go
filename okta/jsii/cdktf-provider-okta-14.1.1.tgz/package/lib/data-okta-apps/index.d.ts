/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaAppsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Search only active applications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/apps#active_only DataOktaApps#active_only}
    */
    readonly activeOnly?: boolean | cdktf.IResolvable;
    /**
    * Specifies whether to include non-active, but not deleted apps in the results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/apps#include_non_deleted DataOktaApps#include_non_deleted}
    */
    readonly includeNonDeleted?: boolean | cdktf.IResolvable;
    /**
    * Searches for applications whose label or name property matches this value exactly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/apps#label DataOktaApps#label}
    */
    readonly label?: string;
    /**
    * Searches for applications whose label or name property begins with this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/apps#label_prefix DataOktaApps#label_prefix}
    */
    readonly labelPrefix?: string;
    /**
    * Searches for applications whose name or label properties that starts with this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/apps#q DataOktaApps#q}
    */
    readonly q?: string;
    /**
    * Specifies whether to use query optimization. If you specify `useOptimization=true` in the request query, the response contains a subset of app instance properties.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/apps#use_optimization DataOktaApps#use_optimization}
    */
    readonly useOptimization?: boolean | cdktf.IResolvable;
}
export interface DataOktaAppsAppsVisibilityHide {
}
export declare function dataOktaAppsAppsVisibilityHideToTerraform(struct?: DataOktaAppsAppsVisibilityHide): any;
export declare function dataOktaAppsAppsVisibilityHideToHclTerraform(struct?: DataOktaAppsAppsVisibilityHide): any;
export declare class DataOktaAppsAppsVisibilityHideOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaAppsAppsVisibilityHide | undefined;
    set internalValue(value: DataOktaAppsAppsVisibilityHide | undefined);
    get ios(): cdktf.IResolvable;
    get web(): cdktf.IResolvable;
}
export interface DataOktaAppsAppsVisibility {
}
export declare function dataOktaAppsAppsVisibilityToTerraform(struct?: DataOktaAppsAppsVisibility): any;
export declare function dataOktaAppsAppsVisibilityToHclTerraform(struct?: DataOktaAppsAppsVisibility): any;
export declare class DataOktaAppsAppsVisibilityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaAppsAppsVisibility | undefined;
    set internalValue(value: DataOktaAppsAppsVisibility | undefined);
    get autoLaunch(): cdktf.IResolvable;
    get autoSubmitToolbar(): cdktf.IResolvable;
    private _hide;
    get hide(): DataOktaAppsAppsVisibilityHideOutputReference;
}
export interface DataOktaAppsApps {
}
export declare function dataOktaAppsAppsToTerraform(struct?: DataOktaAppsApps): any;
export declare function dataOktaAppsAppsToHclTerraform(struct?: DataOktaAppsApps): any;
export declare class DataOktaAppsAppsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOktaAppsApps | undefined;
    set internalValue(value: DataOktaAppsApps | undefined);
    get adminNote(): string;
    get created(): string;
    get enduserNote(): string;
    get features(): string[];
    get id(): string;
    get label(): string;
    get lastUpdated(): string;
    get name(): string;
    get signOnMode(): string;
    get status(): string;
    private _visibility;
    get visibility(): DataOktaAppsAppsVisibilityOutputReference;
}
export declare class DataOktaAppsAppsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOktaAppsAppsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/apps okta_apps}
*/
export declare class DataOktaApps extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_apps";
    /**
    * Generates CDKTF code for importing a DataOktaApps resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaApps to import
    * @param importFromId The id of the existing DataOktaApps that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/apps#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaApps to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/apps okta_apps} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaAppsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaAppsConfig);
    private _activeOnly?;
    get activeOnly(): boolean | cdktf.IResolvable;
    set activeOnly(value: boolean | cdktf.IResolvable);
    resetActiveOnly(): void;
    get activeOnlyInput(): boolean | cdktf.IResolvable | undefined;
    private _apps;
    get apps(): DataOktaAppsAppsList;
    private _includeNonDeleted?;
    get includeNonDeleted(): boolean | cdktf.IResolvable;
    set includeNonDeleted(value: boolean | cdktf.IResolvable);
    resetIncludeNonDeleted(): void;
    get includeNonDeletedInput(): boolean | cdktf.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _labelPrefix?;
    get labelPrefix(): string;
    set labelPrefix(value: string);
    resetLabelPrefix(): void;
    get labelPrefixInput(): string | undefined;
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _useOptimization?;
    get useOptimization(): boolean | cdktf.IResolvable;
    set useOptimization(value: boolean | cdktf.IResolvable);
    resetUseOptimization(): void;
    get useOptimizationInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
