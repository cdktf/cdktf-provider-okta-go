/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AdminRoleCustomConfig extends cdktf.TerraformMetaArguments {
    /**
    * A human-readable description of the new Role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/admin_role_custom#description AdminRoleCustom#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/admin_role_custom#id AdminRoleCustom#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name given to the new Role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/admin_role_custom#label AdminRoleCustom#label}
    */
    readonly label: string;
    /**
    * The permissions that the new Role grants. At least one
    * 				permission must be specified when creating custom role. Valid values: "okta.users.manage",
    * 				"okta.users.create",
    * 				"okta.users.read",
    * 				"okta.users.credentials.manage",
    * 				"okta.users.credentials.resetFactors",
    * 				"okta.users.credentials.resetPassword",
    * 				"okta.users.credentials.expirePassword",
    * 				"okta.users.userprofile.manage",
    * 				"okta.users.lifecycle.manage",
    * 				"okta.users.lifecycle.activate",
    * 				"okta.users.lifecycle.deactivate",
    * 				"okta.users.lifecycle.suspend",
    * 				"okta.users.lifecycle.unsuspend",
    * 				"okta.users.lifecycle.delete",
    * 				"okta.users.lifecycle.unlock",
    * 				"okta.users.lifecycle.clearSessions",
    * 				"okta.users.groupMembership.manage",
    * 				"okta.users.appAssignment.manage",
    * 				"okta.users.apitokens.manage",
    * 				"okta.users.apitokens.read",
    * 				"okta.groups.manage",
    * 				"okta.groups.create",
    * 				"okta.groups.members.manage",
    * 				"okta.groups.read",
    * 				"okta.groups.appAssignment.manage",
    * 				"okta.apps.read",
    * 				"okta.apps.manage",
    * 				"okta.apps.assignment.manage",
    * 				"okta.profilesources.import.run",
    * 				"okta.authzServers.read",
    * 				"okta.users.userprofile.manage",
    * 				"okta.authzServers.manage",
    * 				"okta.customizations.read",
    * 				"okta.customizations.manage",
    * 				"okta.identityProviders.read",
    * 				"okta.identityProviders.manage",
    * 				"okta.workflows.read",
    * 				"okta.workflows.invoke".
    * 				"okta.governance.accessCertifications.manage",
    * 				"okta.governance.accessRequests.manage",
    * 				"okta.apps.manageFirstPartyApps",
    * 				"okta.agents.manage",
    * 				"okta.agents.register",
    * 				"okta.agents.view",
    * 				"okta.directories.manage",
    * 				"okta.directories.read",
    * 				"okta.devices.manage",
    * 				"okta.devices.lifecycle.manage",
    * 				"okta.devices.lifecycle.activate",
    * 				"okta.devices.lifecycle.deactivate",
    * 				"okta.devices.lifecycle.suspend",
    * 				"okta.devices.lifecycle.unsuspend",
    * 				"okta.devices.lifecycle.delete",
    * 				"okta.devices.read",
    * 				"okta.iam.read",
    * 				"okta.support.cases.manage".,
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/admin_role_custom#permissions AdminRoleCustom#permissions}
    */
    readonly permissions?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/admin_role_custom okta_admin_role_custom}
*/
export declare class AdminRoleCustom extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_admin_role_custom";
    /**
    * Generates CDKTF code for importing a AdminRoleCustom resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AdminRoleCustom to import
    * @param importFromId The id of the existing AdminRoleCustom that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/admin_role_custom#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AdminRoleCustom to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/admin_role_custom okta_admin_role_custom} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AdminRoleCustomConfig
    */
    constructor(scope: Construct, id: string, config: AdminRoleCustomConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    resetPermissions(): void;
    get permissionsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
