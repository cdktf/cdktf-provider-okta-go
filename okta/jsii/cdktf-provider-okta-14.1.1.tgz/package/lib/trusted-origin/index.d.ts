/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface TrustedOriginConfig extends cdktf.TerraformMetaArguments {
    /**
    * Whether the Trusted Origin is active or not - can only be issued post-creation. By default, it is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/trusted_origin#active TrustedOrigin#active}
    */
    readonly active?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/trusted_origin#id TrustedOrigin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name for this trusted origin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/trusted_origin#name TrustedOrigin#name}
    */
    readonly name: string;
    /**
    * Unique origin URL for this trusted origin
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/trusted_origin#origin TrustedOrigin#origin}
    */
    readonly origin: string;
    /**
    * Scopes of the Trusted Origin - can either be `CORS` and/or `REDIRECT`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/trusted_origin#scopes TrustedOrigin#scopes}
    */
    readonly scopes: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/trusted_origin okta_trusted_origin}
*/
export declare class TrustedOrigin extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_trusted_origin";
    /**
    * Generates CDKTF code for importing a TrustedOrigin resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TrustedOrigin to import
    * @param importFromId The id of the existing TrustedOrigin that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/trusted_origin#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TrustedOrigin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/trusted_origin okta_trusted_origin} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TrustedOriginConfig
    */
    constructor(scope: Construct, id: string, config: TrustedOriginConfig);
    private _active?;
    get active(): boolean | cdktf.IResolvable;
    set active(value: boolean | cdktf.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _origin?;
    get origin(): string;
    set origin(value: string);
    get originInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
