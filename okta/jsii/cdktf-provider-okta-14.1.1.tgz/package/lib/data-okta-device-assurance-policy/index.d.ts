/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataOktaDeviceAssurancePolicyConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the user type to retrieve, conflicts with `name`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#id DataOktaDeviceAssurancePolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of user type to retrieve, conflicts with `id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#name DataOktaDeviceAssurancePolicy#name}
    */
    readonly name?: string;
    /**
    * Indicates if the device contains a secure hardware functionality
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#secure_hardware_present DataOktaDeviceAssurancePolicy#secure_hardware_present}
    */
    readonly secureHardwarePresent?: boolean | cdktf.IResolvable;
    /**
    * Indicates if the device contains a secure hardware functionality
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#third_party_signal_provider DataOktaDeviceAssurancePolicy#third_party_signal_provider}
    */
    readonly thirdPartySignalProvider?: DataOktaDeviceAssurancePolicyThirdPartySignalProvider;
}
export interface DataOktaDeviceAssurancePolicyDiskEncryptionType {
}
export declare function dataOktaDeviceAssurancePolicyDiskEncryptionTypeToTerraform(struct?: DataOktaDeviceAssurancePolicyDiskEncryptionType): any;
export declare function dataOktaDeviceAssurancePolicyDiskEncryptionTypeToHclTerraform(struct?: DataOktaDeviceAssurancePolicyDiskEncryptionType): any;
export declare class DataOktaDeviceAssurancePolicyDiskEncryptionTypeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDeviceAssurancePolicyDiskEncryptionType | undefined;
    set internalValue(value: DataOktaDeviceAssurancePolicyDiskEncryptionType | undefined);
    get include(): string[];
}
export interface DataOktaDeviceAssurancePolicyOsVersionDynamicVersionRequirement {
}
export declare function dataOktaDeviceAssurancePolicyOsVersionDynamicVersionRequirementToTerraform(struct?: DataOktaDeviceAssurancePolicyOsVersionDynamicVersionRequirement): any;
export declare function dataOktaDeviceAssurancePolicyOsVersionDynamicVersionRequirementToHclTerraform(struct?: DataOktaDeviceAssurancePolicyOsVersionDynamicVersionRequirement): any;
export declare class DataOktaDeviceAssurancePolicyOsVersionDynamicVersionRequirementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDeviceAssurancePolicyOsVersionDynamicVersionRequirement | undefined;
    set internalValue(value: DataOktaDeviceAssurancePolicyOsVersionDynamicVersionRequirement | undefined);
    get distanceFromLatestMajor(): number;
    get latestSecurityPatch(): cdktf.IResolvable;
    get type(): string;
}
export interface DataOktaDeviceAssurancePolicyOsVersion {
}
export declare function dataOktaDeviceAssurancePolicyOsVersionToTerraform(struct?: DataOktaDeviceAssurancePolicyOsVersion): any;
export declare function dataOktaDeviceAssurancePolicyOsVersionToHclTerraform(struct?: DataOktaDeviceAssurancePolicyOsVersion): any;
export declare class DataOktaDeviceAssurancePolicyOsVersionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDeviceAssurancePolicyOsVersion | undefined;
    set internalValue(value: DataOktaDeviceAssurancePolicyOsVersion | undefined);
    private _dynamicVersionRequirement;
    get dynamicVersionRequirement(): DataOktaDeviceAssurancePolicyOsVersionDynamicVersionRequirementOutputReference;
    get minimum(): string;
}
export interface DataOktaDeviceAssurancePolicyOsVersionConstraintDynamicVersionRequirement {
}
export declare function dataOktaDeviceAssurancePolicyOsVersionConstraintDynamicVersionRequirementToTerraform(struct?: DataOktaDeviceAssurancePolicyOsVersionConstraintDynamicVersionRequirement): any;
export declare function dataOktaDeviceAssurancePolicyOsVersionConstraintDynamicVersionRequirementToHclTerraform(struct?: DataOktaDeviceAssurancePolicyOsVersionConstraintDynamicVersionRequirement): any;
export declare class DataOktaDeviceAssurancePolicyOsVersionConstraintDynamicVersionRequirementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDeviceAssurancePolicyOsVersionConstraintDynamicVersionRequirement | undefined;
    set internalValue(value: DataOktaDeviceAssurancePolicyOsVersionConstraintDynamicVersionRequirement | undefined);
    get distanceFromLatestMajor(): number;
    get latestSecurityPatch(): cdktf.IResolvable;
    get type(): string;
}
export interface DataOktaDeviceAssurancePolicyOsVersionConstraint {
}
export declare function dataOktaDeviceAssurancePolicyOsVersionConstraintToTerraform(struct?: DataOktaDeviceAssurancePolicyOsVersionConstraint): any;
export declare function dataOktaDeviceAssurancePolicyOsVersionConstraintToHclTerraform(struct?: DataOktaDeviceAssurancePolicyOsVersionConstraint): any;
export declare class DataOktaDeviceAssurancePolicyOsVersionConstraintOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataOktaDeviceAssurancePolicyOsVersionConstraint | undefined;
    set internalValue(value: DataOktaDeviceAssurancePolicyOsVersionConstraint | undefined);
    private _dynamicVersionRequirement;
    get dynamicVersionRequirement(): DataOktaDeviceAssurancePolicyOsVersionConstraintDynamicVersionRequirementOutputReference;
    get majorVersionConstraint(): string;
}
export declare class DataOktaDeviceAssurancePolicyOsVersionConstraintList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataOktaDeviceAssurancePolicyOsVersionConstraintOutputReference;
}
export interface DataOktaDeviceAssurancePolicyScreenlockType {
}
export declare function dataOktaDeviceAssurancePolicyScreenlockTypeToTerraform(struct?: DataOktaDeviceAssurancePolicyScreenlockType): any;
export declare function dataOktaDeviceAssurancePolicyScreenlockTypeToHclTerraform(struct?: DataOktaDeviceAssurancePolicyScreenlockType): any;
export declare class DataOktaDeviceAssurancePolicyScreenlockTypeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDeviceAssurancePolicyScreenlockType | undefined;
    set internalValue(value: DataOktaDeviceAssurancePolicyScreenlockType | undefined);
    get include(): string[];
}
export interface DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#minimum DataOktaDeviceAssurancePolicy#minimum}
    */
    readonly minimum?: string;
}
export declare function dataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersionToTerraform(struct?: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersion | cdktf.IResolvable): any;
export declare function dataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersionToHclTerraform(struct?: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersion | cdktf.IResolvable): any;
export declare class DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersion | cdktf.IResolvable | undefined;
    set internalValue(value: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersion | cdktf.IResolvable | undefined);
    private _minimum?;
    get minimum(): string;
    set minimum(value: string);
    resetMinimum(): void;
    get minimumInput(): string | undefined;
}
export interface DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#minimum DataOktaDeviceAssurancePolicy#minimum}
    */
    readonly minimum?: string;
}
export declare function dataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersionToTerraform(struct?: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersion | cdktf.IResolvable): any;
export declare function dataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersionToHclTerraform(struct?: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersion | cdktf.IResolvable): any;
export declare class DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersion | cdktf.IResolvable | undefined;
    set internalValue(value: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersion | cdktf.IResolvable | undefined);
    private _minimum?;
    get minimum(): string;
    set minimum(value: string);
    resetMinimum(): void;
    get minimumInput(): string | undefined;
}
export interface DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtc {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#allow_screen_lock DataOktaDeviceAssurancePolicy#allow_screen_lock}
    */
    readonly allowScreenLock?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#browser_version DataOktaDeviceAssurancePolicy#browser_version}
    */
    readonly browserVersion?: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersion;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#built_in_dns_client_enabled DataOktaDeviceAssurancePolicy#built_in_dns_client_enabled}
    */
    readonly builtInDnsClientEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#chrome_remote_desktop_app_blocked DataOktaDeviceAssurancePolicy#chrome_remote_desktop_app_blocked}
    */
    readonly chromeRemoteDesktopAppBlocked?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#crowd_strike_agent_id DataOktaDeviceAssurancePolicy#crowd_strike_agent_id}
    */
    readonly crowdStrikeAgentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#crowd_strike_customer_id DataOktaDeviceAssurancePolicy#crowd_strike_customer_id}
    */
    readonly crowdStrikeCustomerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#device_enrollment_domain DataOktaDeviceAssurancePolicy#device_enrollment_domain}
    */
    readonly deviceEnrollmentDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#disk_encrypted DataOktaDeviceAssurancePolicy#disk_encrypted}
    */
    readonly diskEncrypted?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#key_trust_level DataOktaDeviceAssurancePolicy#key_trust_level}
    */
    readonly keyTrustLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#managed_device DataOktaDeviceAssurancePolicy#managed_device}
    */
    readonly managedDevice?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#os_firewall DataOktaDeviceAssurancePolicy#os_firewall}
    */
    readonly osFirewall?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#os_version DataOktaDeviceAssurancePolicy#os_version}
    */
    readonly osVersion?: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersion;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#password_protection_warning_trigger DataOktaDeviceAssurancePolicy#password_protection_warning_trigger}
    */
    readonly passwordProtectionWarningTrigger?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#realtime_url_check_mode DataOktaDeviceAssurancePolicy#realtime_url_check_mode}
    */
    readonly realtimeUrlCheckMode?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#safe_browsing_protection_level DataOktaDeviceAssurancePolicy#safe_browsing_protection_level}
    */
    readonly safeBrowsingProtectionLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#screen_lock_secured DataOktaDeviceAssurancePolicy#screen_lock_secured}
    */
    readonly screenLockSecured?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#site_isolation_enabled DataOktaDeviceAssurancePolicy#site_isolation_enabled}
    */
    readonly siteIsolationEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#third_party_blocking_enabled DataOktaDeviceAssurancePolicy#third_party_blocking_enabled}
    */
    readonly thirdPartyBlockingEnabled?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#windows_machine_domain DataOktaDeviceAssurancePolicy#windows_machine_domain}
    */
    readonly windowsMachineDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#windows_user_domain DataOktaDeviceAssurancePolicy#windows_user_domain}
    */
    readonly windowsUserDomain?: string;
}
export declare function dataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcToTerraform(struct?: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtc | cdktf.IResolvable): any;
export declare function dataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcToHclTerraform(struct?: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtc | cdktf.IResolvable): any;
export declare class DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtc | cdktf.IResolvable | undefined;
    set internalValue(value: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtc | cdktf.IResolvable | undefined);
    private _allowScreenLock?;
    get allowScreenLock(): boolean | cdktf.IResolvable;
    set allowScreenLock(value: boolean | cdktf.IResolvable);
    resetAllowScreenLock(): void;
    get allowScreenLockInput(): boolean | cdktf.IResolvable | undefined;
    private _browserVersion;
    get browserVersion(): DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersionOutputReference;
    putBrowserVersion(value: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersion): void;
    resetBrowserVersion(): void;
    get browserVersionInput(): cdktf.IResolvable | DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcBrowserVersion | undefined;
    private _builtInDnsClientEnabled?;
    get builtInDnsClientEnabled(): boolean | cdktf.IResolvable;
    set builtInDnsClientEnabled(value: boolean | cdktf.IResolvable);
    resetBuiltInDnsClientEnabled(): void;
    get builtInDnsClientEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _chromeRemoteDesktopAppBlocked?;
    get chromeRemoteDesktopAppBlocked(): boolean | cdktf.IResolvable;
    set chromeRemoteDesktopAppBlocked(value: boolean | cdktf.IResolvable);
    resetChromeRemoteDesktopAppBlocked(): void;
    get chromeRemoteDesktopAppBlockedInput(): boolean | cdktf.IResolvable | undefined;
    private _crowdStrikeAgentId?;
    get crowdStrikeAgentId(): string;
    set crowdStrikeAgentId(value: string);
    resetCrowdStrikeAgentId(): void;
    get crowdStrikeAgentIdInput(): string | undefined;
    private _crowdStrikeCustomerId?;
    get crowdStrikeCustomerId(): string;
    set crowdStrikeCustomerId(value: string);
    resetCrowdStrikeCustomerId(): void;
    get crowdStrikeCustomerIdInput(): string | undefined;
    private _deviceEnrollmentDomain?;
    get deviceEnrollmentDomain(): string;
    set deviceEnrollmentDomain(value: string);
    resetDeviceEnrollmentDomain(): void;
    get deviceEnrollmentDomainInput(): string | undefined;
    private _diskEncrypted?;
    get diskEncrypted(): boolean | cdktf.IResolvable;
    set diskEncrypted(value: boolean | cdktf.IResolvable);
    resetDiskEncrypted(): void;
    get diskEncryptedInput(): boolean | cdktf.IResolvable | undefined;
    private _keyTrustLevel?;
    get keyTrustLevel(): string;
    set keyTrustLevel(value: string);
    resetKeyTrustLevel(): void;
    get keyTrustLevelInput(): string | undefined;
    private _managedDevice?;
    get managedDevice(): boolean | cdktf.IResolvable;
    set managedDevice(value: boolean | cdktf.IResolvable);
    resetManagedDevice(): void;
    get managedDeviceInput(): boolean | cdktf.IResolvable | undefined;
    private _osFirewall?;
    get osFirewall(): boolean | cdktf.IResolvable;
    set osFirewall(value: boolean | cdktf.IResolvable);
    resetOsFirewall(): void;
    get osFirewallInput(): boolean | cdktf.IResolvable | undefined;
    private _osVersion;
    get osVersion(): DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersionOutputReference;
    putOsVersion(value: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersion): void;
    resetOsVersion(): void;
    get osVersionInput(): cdktf.IResolvable | DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOsVersion | undefined;
    private _passwordProtectionWarningTrigger?;
    get passwordProtectionWarningTrigger(): string;
    set passwordProtectionWarningTrigger(value: string);
    resetPasswordProtectionWarningTrigger(): void;
    get passwordProtectionWarningTriggerInput(): string | undefined;
    private _realtimeUrlCheckMode?;
    get realtimeUrlCheckMode(): boolean | cdktf.IResolvable;
    set realtimeUrlCheckMode(value: boolean | cdktf.IResolvable);
    resetRealtimeUrlCheckMode(): void;
    get realtimeUrlCheckModeInput(): boolean | cdktf.IResolvable | undefined;
    private _safeBrowsingProtectionLevel?;
    get safeBrowsingProtectionLevel(): string;
    set safeBrowsingProtectionLevel(value: string);
    resetSafeBrowsingProtectionLevel(): void;
    get safeBrowsingProtectionLevelInput(): string | undefined;
    private _screenLockSecured?;
    get screenLockSecured(): boolean | cdktf.IResolvable;
    set screenLockSecured(value: boolean | cdktf.IResolvable);
    resetScreenLockSecured(): void;
    get screenLockSecuredInput(): boolean | cdktf.IResolvable | undefined;
    private _siteIsolationEnabled?;
    get siteIsolationEnabled(): boolean | cdktf.IResolvable;
    set siteIsolationEnabled(value: boolean | cdktf.IResolvable);
    resetSiteIsolationEnabled(): void;
    get siteIsolationEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _thirdPartyBlockingEnabled?;
    get thirdPartyBlockingEnabled(): boolean | cdktf.IResolvable;
    set thirdPartyBlockingEnabled(value: boolean | cdktf.IResolvable);
    resetThirdPartyBlockingEnabled(): void;
    get thirdPartyBlockingEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _windowsMachineDomain?;
    get windowsMachineDomain(): string;
    set windowsMachineDomain(value: string);
    resetWindowsMachineDomain(): void;
    get windowsMachineDomainInput(): string | undefined;
    private _windowsUserDomain?;
    get windowsUserDomain(): string;
    set windowsUserDomain(value: string);
    resetWindowsUserDomain(): void;
    get windowsUserDomainInput(): string | undefined;
}
export interface DataOktaDeviceAssurancePolicyThirdPartySignalProvider {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#dtc DataOktaDeviceAssurancePolicy#dtc}
    */
    readonly dtc?: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtc;
}
export declare function dataOktaDeviceAssurancePolicyThirdPartySignalProviderToTerraform(struct?: DataOktaDeviceAssurancePolicyThirdPartySignalProvider | cdktf.IResolvable): any;
export declare function dataOktaDeviceAssurancePolicyThirdPartySignalProviderToHclTerraform(struct?: DataOktaDeviceAssurancePolicyThirdPartySignalProvider | cdktf.IResolvable): any;
export declare class DataOktaDeviceAssurancePolicyThirdPartySignalProviderOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataOktaDeviceAssurancePolicyThirdPartySignalProvider | cdktf.IResolvable | undefined;
    set internalValue(value: DataOktaDeviceAssurancePolicyThirdPartySignalProvider | cdktf.IResolvable | undefined);
    private _dtc;
    get dtc(): DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtcOutputReference;
    putDtc(value: DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtc): void;
    resetDtc(): void;
    get dtcInput(): cdktf.IResolvable | DataOktaDeviceAssurancePolicyThirdPartySignalProviderDtc | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy okta_device_assurance_policy}
*/
export declare class DataOktaDeviceAssurancePolicy extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "okta_device_assurance_policy";
    /**
    * Generates CDKTF code for importing a DataOktaDeviceAssurancePolicy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataOktaDeviceAssurancePolicy to import
    * @param importFromId The id of the existing DataOktaDeviceAssurancePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataOktaDeviceAssurancePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/data-sources/device_assurance_policy okta_device_assurance_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataOktaDeviceAssurancePolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataOktaDeviceAssurancePolicyConfig);
    private _diskEncryptionType;
    get diskEncryptionType(): DataOktaDeviceAssurancePolicyDiskEncryptionTypeOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get jailbreak(): cdktf.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _osVersion;
    get osVersion(): DataOktaDeviceAssurancePolicyOsVersionOutputReference;
    private _osVersionConstraint;
    get osVersionConstraint(): DataOktaDeviceAssurancePolicyOsVersionConstraintList;
    get platform(): string;
    private _screenlockType;
    get screenlockType(): DataOktaDeviceAssurancePolicyScreenlockTypeOutputReference;
    private _secureHardwarePresent?;
    get secureHardwarePresent(): boolean | cdktf.IResolvable;
    set secureHardwarePresent(value: boolean | cdktf.IResolvable);
    resetSecureHardwarePresent(): void;
    get secureHardwarePresentInput(): boolean | cdktf.IResolvable | undefined;
    private _thirdPartySignalProvider;
    get thirdPartySignalProvider(): DataOktaDeviceAssurancePolicyThirdPartySignalProviderOutputReference;
    putThirdPartySignalProvider(value: DataOktaDeviceAssurancePolicyThirdPartySignalProvider): void;
    resetThirdPartySignalProvider(): void;
    get thirdPartySignalProviderInput(): cdktf.IResolvable | DataOktaDeviceAssurancePolicyThirdPartySignalProvider | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
