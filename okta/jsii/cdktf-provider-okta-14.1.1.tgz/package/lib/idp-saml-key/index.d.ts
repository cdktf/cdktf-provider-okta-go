/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IdpSamlKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/idp_saml_key#id IdpSamlKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * base64-encoded X.509 certificate chain with DER encoding
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/idp_saml_key#x5c IdpSamlKey#x5c}
    */
    readonly x5C: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/idp_saml_key okta_idp_saml_key}
*/
export declare class IdpSamlKey extends cdktf.TerraformResource {
    static readonly tfResourceType = "okta_idp_saml_key";
    /**
    * Generates CDKTF code for importing a IdpSamlKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IdpSamlKey to import
    * @param importFromId The id of the existing IdpSamlKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/idp_saml_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IdpSamlKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/okta/okta/4.20.0/docs/resources/idp_saml_key okta_idp_saml_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdpSamlKeyConfig
    */
    constructor(scope: Construct, id: string, config: IdpSamlKeyConfig);
    get created(): string;
    get expiresAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kid(): string;
    get kty(): string;
    get use(): string;
    private _x5C?;
    get x5C(): string[];
    set x5C(value: string[]);
    get x5CInput(): string[] | undefined;
    get x5TS256(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
